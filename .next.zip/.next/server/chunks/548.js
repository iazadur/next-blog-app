"use strict";
exports.id = 548;
exports.ids = [548];
exports.modules = {

/***/ 548:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   jW: () => (/* binding */ useAddPostMutation),
/* harmony export */   mD: () => (/* binding */ useGetAllPostsQuery),
/* harmony export */   vr: () => (/* binding */ useGetAnPostQuery)
/* harmony export */ });
/* unused harmony exports postApi, useUpdatePostMutation, useDeletePostMutation */
/* harmony import */ var _api_apiSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7687);

const url = "/posts";
const postApi = _api_apiSlice__WEBPACK_IMPORTED_MODULE_0__/* .apiSlice */ .g.injectEndpoints({
    endpoints: (builder)=>({
            getAnPost: builder.query({
                query: (id)=>`${url}/${id}`,
                keepUnusedDataFor: 600,
                providesTags: [
                    "Posts"
                ]
            }),
            getAllPosts: builder.query({
                query: ()=>url,
                keepUnusedDataFor: 600,
                providesTags: [
                    "Posts"
                ]
            }),
            addPost: builder.mutation({
                query: (data)=>({
                        url,
                        method: "POST",
                        body: data
                    }),
                invalidatesTags: [
                    "Posts"
                ],
                async onQueryStarted (arg, { queryFulfilled , dispatch  }) {
                    try {
                        const result = await queryFulfilled;
                        console.log(result);
                    // if (result.data.isSuccess) {
                    // toast.success(result?.data?.message)
                    // }
                    // if (!result.data.isSuccess) {
                    // toast.warning(result?.data?.message)
                    // }
                    } catch (err) {
                    // do nothing 
                    }
                }
            }),
            updatePost: builder.mutation({
                query: (data)=>({
                        url,
                        method: "PUT",
                        body: data
                    }),
                invalidatesTags: [
                    "Post"
                ],
                async onQueryStarted (arg, { queryFulfilled , dispatch  }) {
                    try {
                        const result = await queryFulfilled;
                        console.log(result);
                    // if (result.data.isSuccess) {
                    // toast.success(result?.data?.message)
                    // }
                    // if (!result.data.isSuccess) {
                    // toast.warning(result?.data?.message)
                    // }
                    } catch (err) {
                    // do nothing 
                    }
                }
            }),
            deletePost: builder.mutation({
                query: (id)=>({
                        url: `${url}/${id}`,
                        method: "DELETE"
                    }),
                invalidatesTags: [
                    "Post"
                ]
            })
        })
});
const { useGetAnPostQuery , useGetAllPostsQuery , useAddPostMutation , useUpdatePostMutation , useDeletePostMutation  } = postApi;


/***/ })

};
;