exports.id = 503;
exports.ids = [503];
exports.modules = {

/***/ 764:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3100, 23))

/***/ }),

/***/ 7275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bl: () => (/* binding */ useSignupMutation),
/* harmony export */   YA: () => (/* binding */ useLoginMutation)
/* harmony export */ });
/* unused harmony export authApi */
/* harmony import */ var _api_apiSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7687);
/* harmony import */ var _authSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4591);


const authApi = _api_apiSlice__WEBPACK_IMPORTED_MODULE_0__/* .apiSlice */ .g.injectEndpoints({
    endpoints: (builder)=>({
            login: builder.mutation({
                query: (data)=>({
                        url: "/users/login",
                        method: "POST",
                        body: data
                    }),
                invalidatesTags: [
                    "User"
                ],
                async onQueryStarted (arg, { queryFulfilled , dispatch  }) {
                    try {
                        const result = await queryFulfilled;
                        localStorage.setItem("auth", JSON.stringify({
                            accessToken: result.data?.token,
                            user: result.data?.data?.user
                        }));
                        dispatch((0,_authSlice__WEBPACK_IMPORTED_MODULE_1__/* .userLoggedIn */ .nD)({
                            accessToken: result.data?.token,
                            user: result.data?.data?.user
                        }));
                    } catch (err) {
                    // do nothing 
                    }
                }
            }),
            signup: builder.mutation({
                query: (data)=>({
                        url: "/users/signup",
                        method: "POST",
                        body: data
                    }),
                invalidatesTags: [
                    "User"
                ],
                async onQueryStarted (arg, { queryFulfilled , dispatch  }) {
                    try {
                        const result = await queryFulfilled;
                        console.log(result.data);
                    // console.log(result.data?.token);
                    // console.log(result.data?.data?.user);
                    // localStorage.setItem("auth", JSON.stringify({
                    //     accessToken: result.data.data.token,
                    //     user: result.data.data.user
                    // }))
                    // dispatch(userLoggedIn({
                    //     accessToken: result.data.data.token,
                    //     user: result.data.data.user
                    // }))
                    } catch (err) {
                    // do nothing 
                    }
                }
            })
        })
});
const { useLoginMutation , useSignupMutation  } = authApi;


/***/ }),

/***/ 9483:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(5171)


/***/ })

};
;